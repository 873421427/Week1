import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.logging.Logger;



public final class Caculator
{
	private static double sum=0;
	private JTextField firstNumber;
	private JTextField operator;
	private JTextField secondNumber;
	private JTextField equal;
	private JTextField outcome;
	private JFrame frame;


	private static final int width=100;
	private	static final int totalWidth=500; 


	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				try
				{
					Caculator window=new Caculator();

					window.frame.setVisible(true);
				}
				catch (Exception e)
				{
					Logger logger=Logger.getLogger("log");

					logger.info("ini error");
				}
			}
		});
	}

	
	private Caculator()
	{
		initialize();
	}
	

	private void initialize()
	{
		frame=new JFrame();
		frame.setBounds(width,width,totalWidth,totalWidth);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		fieldInitialize();
		buttonInitialize();



	}

	private void fieldInitialize()
	{
		// first line
		firstNumber=new JTextField("12");
		firstNumber.setBounds(0,0,width,width);
		frame.getContentPane().add(firstNumber);

		operator=new JTextField("");
		operator.setBounds(width,0,width,width);
		operator.setEditable(false);

		frame.getContentPane().add(operator);

		secondNumber = new JTextField("2");
		secondNumber.setBounds(2*width,0,width,width);
		frame.getContentPane().add(secondNumber);

		equal= new JTextField("=");
		equal.setBounds(3*width,0,width,width);
		equal.setEditable(false);
		frame.getContentPane().add(equal);

		outcome=new JTextField("");
		outcome.setBounds(4*width,0,width,width);
		outcome.setEditable(false);
		frame.getContentPane().add(outcome);		
	}

	private void buttonInitialize()
	{
		JButton plus=new JButton("+");
		plus.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				String jia="+";
				operator.setText(jia);
			}
		});
		plus.setBounds(0,width,width,width);
		frame.getContentPane().add(plus);

		JButton minus=new JButton("-");
		minus.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				operator.setText("-");
			}
		});
		minus.setBounds(width,width,width,width);
		frame.getContentPane().add(minus);

		JButton multiply=new JButton("*");
		multiply.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				operator.setText("*");
			}
		});
		multiply.setBounds(2*width,width,width,width);
		frame.getContentPane().add(multiply);	

		JButton devide=new JButton("/");
		devide.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				operator.setText("/");
			}
		});
		devide.setBounds(3*width,width,width,width);
		frame.getContentPane().add(devide);

		JButton equalOutcome=new JButton("=");
		equalOutcome.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				setOutcome();
			}
		});
		equalOutcome.setBounds(4*width,width,width,width);
		frame.getContentPane().add(equalOutcome);
	}

	private void setOutcome()
	{
		try
		{
			double number1=Double.parseDouble(firstNumber.getText());
			double number2=Double.parseDouble(secondNumber.getText());
			switch(operator.getText())
			{
				case "+":
				sum=number1+number2;
				break;

				case "-":
				sum=number1-number2;
				break;

				case "*":
				sum=number1*number2;
				break;

				case "/":
				sum=number1/number2;
				break;
				
				default:
				break;
			}

			
			outcome.setText(""+sum);
		}
		catch(Exception ex)
		{
			Logger logger=Logger.getLogger("log");
			logger.info("sum error");
		}
	}
}