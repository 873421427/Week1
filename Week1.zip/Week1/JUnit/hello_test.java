import org.junit.Test;
import static org.junit.Assert.*;

public class hello_test
{


	@Test
	public void helloo()
	{
		hello hi=new hello();
		assertEquals("Hello World!", hi.getStr());
	}

}